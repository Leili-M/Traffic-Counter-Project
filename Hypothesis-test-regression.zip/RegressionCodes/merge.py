from openpyxl import load_workbook, Workbook
import os
import datetime

def merge(d1 ,d2):
    directory1 = 'adjust/'+d1+'adjust'
    directory2 = 'adjust/'+d2+'adjust'

    output_directory ='finaldata/'+ d1[:-3] + d1[-2:]
    os.makedirs(output_directory, exist_ok=True)

    files1 = os.listdir(directory1)
    files2 = os.listdir(directory2)

    for file in files1:

        if file in files2:
            file_path1 = os.path.join(directory1, file)
            file_path2 = os.path.join(directory2, file)

            wb1 = load_workbook(file_path1)
            wb2 = load_workbook(file_path2)

            wb_merged = Workbook()
            ws_merged = wb_merged.active
            ws_merged.sheet_view.rightToLeft = True
            for ws2 in wb2:
                for row in ws2.iter_rows(values_only=True):
                    ws_merged.append(row)

            for ws1 in wb1:
                for row in ws1.iter_rows(values_only=True , min_row=2):
                    ws_merged.append(row)
            merged_file_name = file.replace('.xlsx', '_merged.xlsx')
            merged_file_path = os.path.join(output_directory, merged_file_name)

            wb_merged.save(merged_file_path)

            wb1.close()
            wb2.close()
            wb_merged.close()
