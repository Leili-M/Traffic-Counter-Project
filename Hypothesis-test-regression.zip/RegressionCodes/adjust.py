from openpyxl import load_workbook, Workbook
import os


def adjudt(d):
    directory = 'filter/'+d+'filtered'

    output_directory = 'adjust/'+d+'adjust'
    os.makedirs(output_directory, exist_ok=True)

    print(os.listdir(directory))
    excel_files = [file for file in os.listdir(directory) if file.endswith('.xlsx')]

    for file in excel_files:
        file_path = os.path.join(directory, file)
        wb = load_workbook(file_path)
        ws = wb.active

        wb_new = Workbook()
        ws_new = wb_new.active
        ws_new.sheet_view.rightToLeft = True
        f_r_v = [cell.value for cell in ws[1]]

        ws_new.append(f_r_v)
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row, values_only=True):
            if int(row[4]) < 1440 :
                row = list(row)
                ws_new.append(row[:4] + [1440 , round(row[5]*1440/row[4]) , round(row[6]*1440/row[4])])
            else:
                ws_new.append(row)
        wb_new_file_path = os.path.join(output_directory, file)
        wb_new_file_path = wb_new_file_path.replace('.xlsx', '_adjusted.xlsx')
        wb_new.save(wb_new_file_path)

        wb.close()