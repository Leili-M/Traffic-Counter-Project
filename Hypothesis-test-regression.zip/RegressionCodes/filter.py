from openpyxl import load_workbook, Workbook
import os
import datetime

def filter(d , date , month):
    directory = 'data/'+d

    output_directory = 'Week1/'+d+'filtered'
    os.makedirs(output_directory, exist_ok=True)

    print(os.listdir(directory))
    excel_files = [file for file in os.listdir(directory) if file.endswith('.xlsx')]

    for file in excel_files:
        file_path = os.path.join(directory, file)
        wb = load_workbook(file_path)
        ws = wb.active

        wb_new = Workbook()
        ws_new = wb_new.active
        ws_new.sheet_view.rightToLeft = True
        f_r_v = [cell.value for cell in ws[2]]

        ws_new.append((f_r_v[0] , f_r_v[1], f_r_v [2] ,f_r_v [3] , f_r_v[4] ,f_r_v [6] ,f_r_v [7]))
        if month == 'F' :
            for row in ws.iter_rows(min_row=3, max_row=ws.max_row, values_only=True):
            
             if datetime.datetime.strptime(row[2].split()[0], '%Y/%m/%d') < datetime.datetime.strptime(row[2].split()[0] , '%Y/%m/%d'):
                 ws_new.append((row[0] , row[1] , row[2] , row[3] , row[4] , row[6] , row[7]))
        else:
           for row in ws.iter_rows(min_row=3, max_row=ws.max_row, values_only=True):
            
             if datetime.datetime.strptime(row[2].split()[0], '%Y/%m/%d') > datetime.datetime.strptime(date, '%Y/%m/%d'):
                 ws_new.append((row[0] , row[1] , row[2] , row[3] , row[4] , row[6] , row[7]))
           
        
        
        wb_new_file_path = os.path.join(output_directory, file)
        wb_new_file_path = wb_new_file_path.replace('.xlsx', '_filtered.xlsx')
        wb_new.save(wb_new_file_path)

        wb.close()


