import os
import pandas as pd
from rtl import *

directory = 'Gilan95'
print(os.listdir(directory))
excel_files = [file for file in os.listdir(directory) if file.endswith('.xlsx')]
cities = {}

for file in excel_files:
    file_path = os.path.join(directory, file)
    f = pd.read_excel(file_path, usecols=[1])
    
    f = f.iloc[1, 0].split("-")
    city1 = f[0].replace("(" , "-").split("-")[0].strip()
    print(city1)
    city2 = f[1].strip().replace("(" , "-").split("-")[0].strip()

    df = pd.read_excel(file_path, usecols=[6, 7])
    sum_column_6 = df.iloc[1:, 0].sum()
    sum_column_7 = df.iloc[1:, 1].sum()
    
    if city1 not in cities:
        cities[city1] = {"in": 0, "out": sum_column_6 + sum_column_7}
    else:
        cities[city1]["out"] += sum_column_6 + sum_column_7

    if city2 not in cities.keys():
        cities[city2] = {"in": sum_column_6 + sum_column_7, "out": 0}
    else:
        cities[city2]["in"] += sum_column_6 + sum_column_7
    
    print("Done")
    


result_df = pd.DataFrame(cities).T.reset_index()
result_df.columns = ["نام شهر", "ورودی", "خروجی"]

result_df.to_excel('Gilan95result.xlsx', index=False)
