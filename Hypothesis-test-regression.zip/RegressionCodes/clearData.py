import filter  , adjust , merge , filterWeekly
Mazandaran_F = {'MazandaranF02':'1402/01/19' , 'MazandaranF01':'1401/01/19' , 'MazandaranF00':'1400/01/20'}
Mazandaran_E = {'MazandaranE01':'1401/12/24' , 'MazandaranE00':'1400/12/24' , 'MazandaranE99':'1399/12/20'}

Gilan_F = {'GilanF02':'1402/01/19' , 'GilanF01':'1401/01/19' , 'GilanF00':'1400/01/20'} 
Gilan_E = {'GilanE01':'1401/12/24' , 'GilanE00':'1400/12/24' , 'GilanE99':'1399/12/20'}

Golestan_F = {'GolestanF01':'1401/01/19' , 'GolestanF00':'1400/01/20' }
Golestan_E = {'GolestanE00':'1400/12/24' , 'GolestanE99':'1399/12/20'}


#Mazandaran
# for city in Mazandaran_F:
#     filter.filter(city , Mazandaran_F.get(city) , 'F')
#     adjust.adjudt(city)

# for city in Mazandaran_E :
#     filter.filter(city , Mazandaran_E.get(city) , 'E')
#     adjust.adjudt(city)

# for F,E in zip(Mazandaran_F , Mazandaran_E):
#     merge.merge(F , E)


# #Gilan
    
# for city in Gilan_F:
#     filter.filter(city , Gilan_F.get(city) , 'F')
#     adjust.adjudt(city)

# for city in Gilan_E :
#     filter.filter(city , Gilan_E.get(city) , 'E')
#     adjust.adjudt(city)

# for F,E in zip(Gilan_F , Gilan_E):
#     merge.merge(F , E)
   
     
# #Golestan
    
# for city in Golestan_F:
#     filter.filter(city , Golestan_F.get(city) , 'F')
#     adjust.adjudt(city)

# for city in Golestan_E :
#     filter.filter(city , Golestan_E.get(city) , 'E')
#     adjust.adjudt(city)

# for F,E in zip(Golestan_F , Golestan_E):
#     merge.merge(F , E)

#filter weekly
cities = {'Mazandaran02' , 'Mazandaran01' , 'Mazandaran00' ,'Gilan02', 'Gilan01' , 'Gilan00' ,'Golestan01' , 'Golestan00'  }
for data in cities:
    filterWeekly.filter(data)
    print(data , "Done")
