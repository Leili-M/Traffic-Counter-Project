from openpyxl import load_workbook, Workbook
import os

def filter(d):
        directory = 'finaldata/' + d
        excel_files = [file for file in os.listdir(directory) if file.endswith('.xlsx')]

        for file in excel_files:
            file_path = os.path.join(directory, file)
            wb = load_workbook(file_path)
            ws = wb.active
            minrow = 2
            maxrow = 8
            for i in range(4):
             output_directory = 'Week'+str(i+1)+'/' + d 
             os.makedirs(output_directory, exist_ok=True)
            #  print(os.listdir(directory))
             wb_new = Workbook()
             ws_new = wb_new.active
             ws_new.sheet_view.rightToLeft = True
             f_r_v = [cell.value for cell in ws[1]]
             ws_new.append(f_r_v)
             if i == 3:
                 maxrow = ws.max_row
             for row in ws.iter_rows(min_row=minrow, max_row=maxrow):
                row_data = [cell.value for cell in row]
               #  print(row_data)
                ws_new.append(row_data)
            
             file_name =  file.replace("_filtered_adjusted_merged", "_week"+str(i+1))
             
             output_file_path = os.path.join(output_directory, file_name)
             wb_new.save(output_file_path)
             minrow += 7
             maxrow += 7
           

            



