
library(readxl)
library(writexl)
name <-"Gilan02"
source <- paste0("Weekly/Week3/",name)
all_files <- list.files(path = source, pattern = "\\.xlsx$|.lxs$", full.names = TRUE)
print(all_files)
sum_df <- data.frame("day","traffic")
sum <- c(0,0,0,0,0,0,0)
day <- c(1,2,3,4,5,6,7)
for (file in all_files) {
  data <-read_excel(file)
  if(nrow(data)>1){
  for (i in seq(1,nrow(data))) {
    
    sum[[i]] <- sum[[i]] + data$`تعداد وسیله نقلیه کلاس 1`[[i]] +data$`تعداد وسیله نقلیه کلاس 2`[[i]]
  }
  }
}
sum_df <-data.frame(day,sum)

write_xlsx(sum_df, paste0(name,"_weekly2.xlsx"))
