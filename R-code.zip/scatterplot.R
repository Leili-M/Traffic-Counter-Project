library(readr)
library(writexl)
source1 <- "regression1397/"
source0 <- "regression1396/"
source2 <- "regression1398/"

source3 <- "regression1401/"
source4 <- "regression1400/"

files_list0 <- list.files(path = source0)
files_list1 <- list.files(path = source1)
files_list2 <- list.files(path = source2)
files_list3 <- list.files(path = source3)
files_list4 <- list.files(path = source4)

predict1402 <- function(city4,city3,city2,city1,city0){
  name <- basename(city0)
  directory0 <- paste0(source0,city0)
  directory1 <- paste0(source1,city1)
  directory2 <- paste0(source0,city2)
  directory3 <- paste0(source1,city3)
  directory4 <- paste0(source0,city4)
  
  my_city4 <- read.csv(directory0)
  my_city3 <- read.csv(directory1)
  my_city2 <- read.csv(directory0)
  my_city1 <- read.csv(directory1)
  my_city0 <- read.csv(directory0)
  y_values1 <- my_city0$Output[1:20]
  y_values2 <- my_city1$Output[1:20]
  y_values3 <- my_city2$Output[1:20]
  y_values4 <- my_city3$Output[1:20]
  y_values5 <- my_city4$Output[1:20]
  
  x_values <- 1:20
  data <-data.frame(y_values1,y_values2)
  data<- data.frame(data,x_values)
  
  y_min <- min(y_values1,y_values2,y_values3,y_values4,y_values5)
  y_max <- max(y_values1,y_values2,y_values3,y_values4,y_values5)
  
  plot(x_values,y_values1,col = "blue",ylim = c(y_min , y_max), xlab = "Day",ylab =  "output", main = name)
  points(x_values,y_values2,col = "red")
  points(x_values,y_values3,col = "yellow")
  points(x_values,y_values4,col = "green")
  points(x_values,y_values5,col = "purple")
  legend("topright", legend = c("1397","1398","1396","1401","1400"),col =  c("blue","red","yellow","green","purple") , pch = 1)

}
for (i in seq(1,length(files_list0))) {
  predict1402(files_list4[[i]],files_list3[[i]],files_list2[[i]],files_list1[[i]],files_list0[[i]])
  
}
