library(readr)
library(writexl)
source1 <- "regression1401/"
source0 <- "regression1400/"
source2 <- "regression1402/"

files_list0 <- list.files(path = source0)
files_list1 <- list.files(path = source1)
print(files_list0)
print(files_list1)
predict1402 <- function(city0,city1){
  name <- basename(city0)
  directory0 <- paste0(source0,city0)
  directory1 <- paste0(source1,city1)
  directory2 <- paste0(source2,name)
  my_city1 <- read.csv(directory1)
  my_city0 <- read.csv(directory0)
  my_city0 <- my_city0[-c(21:nrow(my_city0)), ] 
  my_city1 <- my_city1[-c(21:nrow(my_city1)), ] 
  View(my_city1)
  View(my_city0)
  my_city2 <- data.frame(my_city0$City, 
                         ceiling((my_city0$Output + my_city1$Output )/2 ),
                         ceiling((my_city0$Input + my_city1$Input )/2))
  colnames(my_city2) <- c("city","Left","Entered") 
  write_xlsx(my_city2, paste0(directory2,".xlsx"))
}
for (i in seq(1,length(files_list0))) {
  predict1402(files_list0[[i]],files_list1[[i]])
}