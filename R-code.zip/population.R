library(readxl)
library("writexl")
population <- read_excel("New folder/census95_cities_poulation.xlsx")
data <- read_excel("New folder/Gilan1395.xlsx")
new_pop1 <- subset(population, select = c(...5,...7))
new_pop <- subset(population , ...5 %in% c("آستارا ","آستانه اشرفیه", "املش" , "بندر انزلی","سیاهکل" , "ماسال",
                                     "رضوان شهر", "لاهیجان","رودبار","رودسر","شفت" ,"صومعه سرا","طوالش ","فومن","لاهیجان","لنگرود" ))
names(new_pop)[which(names(new_pop)=="...5")] <-"X.city."
names(new_pop)[which(names(new_pop)=="...7")] <-"population"
View(new_pop)
merged <- merge(data,new_pop, by = "X.city.",all.x = TRUE)
View(data)

source_path <- "New folder"
dataG <- read_excel("New folder/Gilan1396.xlsx")
dataM <- read_excel("New folder/Mazandaran1396.xlsx")
dataS <- read_excel("New folder/Golestan1396.xlsx")
all_files <- list.files(path = source_path, pattern = "\\.xlsx$|.lxs$", full.names = TRUE)

for (file in all_files) {
  file$population = dataM$population
  write_xlsx(sum_df, "reg_data2\\Golestan1398.xlsx")
}
# View the resulting data frame



