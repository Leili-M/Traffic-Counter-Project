library(readxl)
library("writexl")
year <- "1395"

folder<- "New folder/"
source_path <- paste0(folder,year)
print(source_path)
all_files <- list.files(path = source_path, pattern = "\\.xlsx$|.lxs$",recursive = TRUE, full.names = TRUE)
print(all_files)
city <- "رشت"
sum_df <- data.frame("entered","left")  # Initialize empty data frame
string1 <- "- "
string2 <- " -"
enter_city <- paste(city, string1)
left_city <- paste(string2, city)
# Files with data of the roads people leave a specific city
Left <- grep(left_city, all_files, value = TRUE)

left_data <- lapply(Left, read_excel)
z <-0
x<-0
y<-0
r<-0
# Files with data of the roads people enter a specific city
Entered <- grep(enter_city, all_files, value = TRUE)
entered_data <- lapply(Entered, read_excel)

for (df in entered_data) {
  df2 <-  df[-(22:33),]
  sum_df$X.entered. <-df2$"تعداد وسیله نقلیه کلاس 2" + df2$"تعداد وسیله نقلیه کلاس 1" + sum_df$X.entered.
  
}


m<-0
n<-0
o<-0
k<-0

for (df in left_data) {
  df3 <-df[-(22:33),]
  sum_df$X.entered. <-df3$"تعداد وسیله نقلیه کلاس 2" + df3$"تعداد وسیله نقلیه کلاس 1" + sum_df$X.entered.

}
k <- k/length(left_data)

vector <- list(z,o,r,k)
# Bind rows to sum_df
sum_df <- rbind(sum_df,vector)


# View the resulting data frame
View(sum_df)
destination <- "New folder\\"
xlsx <- ".xlsx"
file1 <- paste0(destination,city)
file2 <- paste0(year,xlsx)
final <- paste0(file1,file2)
#write_xlsx(sum_df, final)





